package token_stream; 

public class TokenInputStream {

    static {
        System.load("C:\\Users\\sedezeeu\\Documents\\token_stream\\fileIn.dll"); 
    }

    private native char[] getPath(String path);
    
    public void path(String path) {
        getPath(path); 
    }
}